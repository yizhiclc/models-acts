/* No dependencies. Rebuild the standalone offline document. */
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'src/style.css'),'utf8');
html=html.replace('<link rel="stylesheet" href="src/style.css">',()=>'<style>\n'+css+'\n</style>');
const scripts=['vendor/three.min.js','src/world.js','src/spectrum.js','src/aircraft.js','src/vegetation.js','src/environment.js','src/optics.js','src/app.js'];
const bundled=scripts.map(f=>'<script>\n/* '+f+' */\n'+fs.readFileSync(path.join(root,f),'utf8').replace(/<\/script/gi,'<\\/script')+'\n</script>').join('\n');
html=html.replace(/<!-- OFFLINE_SCRIPTS_START -->[\s\S]*?<!-- OFFLINE_SCRIPTS_END -->/,()=>bundled);
const license=fs.readFileSync(path.join(root,'vendor/THREE-LICENSE.txt'),'utf8');
html=html.replace('<head>','<head>\n<!-- Three.js r160.1; MIT license:\n'+license.replace(/-->/g,'-- >')+'\n-->');
const dest=process.argv[2]?path.resolve(process.argv[2]):path.join(root,'掠海长航.html');
fs.writeFileSync(dest,html,'utf8');
console.log(JSON.stringify({output:dest,bytes:Buffer.byteLength(html),externalScripts:(html.match(/<script[^>]+src=/gi)||[]).length,externalStyles:(html.match(/<link[^>]+stylesheet/gi)||[]).length},null,2));
