/* No npm installation required. Build with: node build.js */
const fs=require('node:fs');
const path=require('node:path');
const root=__dirname;
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const script=s=>'<script>\n'+s.replace(/<\/script/gi,'<\\/script')+'\n</script>';
const template=read('src/index.html');
const bundled=template.replace('<!-- STYLE -->',()=>'<style>\n'+read('src/style.css')+'\n</style>')
  .replace('<!-- ENGINE -->',()=>'<!-- Bundled Three.js license:\n'+read('vendor/LICENSE-three.txt')+'\n-->\n'+script(read('vendor/three.min.js')))
  .replace('<!-- SIMULATION -->',()=>script(read('src/simulation.js')))
  .replace('<!-- WATER -->',()=>script(read('src/water.js')))
  .replace('<!-- APP -->',()=>script(read('src/app.js')))
  .replace('<!-- QA -->',()=>script(read('src/qa.js')));
fs.writeFileSync(path.join(root,'深海启航.html'),bundled);
const dev=template.replace('<!-- STYLE -->','<link rel="stylesheet" href="src/style.css">')
  .replace('<!-- ENGINE -->','<script src="vendor/three.min.js"></script>')
  .replace('<!-- SIMULATION -->','<script src="src/simulation.js"></script>')
  .replace('<!-- WATER -->','<script src="src/water.js"></script>')
  .replace('<!-- APP -->','<script src="src/app.js"></script>')
  .replace('<!-- QA -->','<script src="src/qa.js"></script>');
fs.writeFileSync(path.join(root,'index.html'),dev);
console.log('Built 深海启航.html: '+Buffer.byteLength(bundled)+' bytes; offline, no external runtime resources.');
