/* Reflective, refractive ocean: all resources are generated locally. */
window.createOcean=function(THREE,renderer,scene,M){
  const uniforms={uTime:{value:0},uDay:{value:1},uSun:{value:new THREE.Vector3(-.5,.7,.4)},uEvent:{value:0},uOrigin:{value:new THREE.Vector2(5,1.85)},uFire:{value:0},uTail:{value:0},uReflection:{value:null},uRefraction:{value:null},uDepth:{value:null},uTextureMatrix:{value:new THREE.Matrix4()},uResolution:{value:new THREE.Vector2(1,1)},uNear:{value:.12},uFar:{value:14000},uUnder:{value:1}};
  const waves=`float wave(vec2 p,float t){return .42*sin(p.x*.066+p.y*.038+t*.85)+.21*sin(p.x*.115-p.y*.069-t*.62)+.11*sin(p.x*.219+p.y*.18+t*1.12)+.045*sin(p.x*.44-p.y*.28+t*1.7);}`;
  const material=new THREE.ShaderMaterial({side:THREE.DoubleSide,transparent:false,depthWrite:true,extensions:{derivatives:true},uniforms,
    vertexShader:`uniform float uTime,uEvent;uniform vec2 uOrigin;uniform mat4 uTextureMatrix;varying vec3 vWorld;varying vec4 vReflect;varying float vViewDepth;${waves}
    void main(){vec3 p=position;float d=distance(p.xz,uOrigin);float ripple=sin(d*1.65-uEvent*5.)*exp(-pow((d-uEvent*2.6)/3.4,2.))*.20*exp(-uEvent*.24)*step(.01,uEvent);p.y=wave(p.xz,uTime)+ripple;vWorld=p;vReflect=uTextureMatrix*vec4(p,1.);vec4 mv=modelViewMatrix*vec4(p,1.);vViewDepth=-mv.z;gl_Position=projectionMatrix*mv;}`,
    fragmentShader:`uniform float uTime,uDay,uEvent,uFire,uTail,uNear,uFar,uUnder;uniform vec2 uOrigin,uResolution;uniform vec3 uSun;uniform sampler2D uReflection,uRefraction,uDepth;varying vec3 vWorld;varying vec4 vReflect;varying float vViewDepth;
    ${waves}
    float hash2(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
    float noise2(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash2(i),hash2(i+vec2(1.,0.)),f.x),mix(hash2(i+vec2(0.,1.)),hash2(i+vec2(1.,1.)),f.x),f.y);}
    float fine(vec2 p,float t){vec2 q=p*.57+vec2(t*.27,-t*.17);float h=0.,a=.15;for(int i=0;i<4;i++){h+=(noise2(q)-.5)*a;q=mat2(1.62,1.17,-1.17,1.62)*q+vec2(.1*t);a*=.51;}return h+sin(dot(p,vec2(.72,.48))+t*.7+noise2(p*.21)*2.)*.026;}
    float surface(vec2 p){return wave(p,uTime)+fine(p,uTime);}
    float linearZ(float d){return uNear*uFar/((uFar-uNear)*d-uFar);}
    void main(){vec2 p=vWorld.xz;float micro=fine(p,uTime)*(1.-smoothstep(800.,6000.,vViewDepth));vec3 microSurface=vWorld+vec3(0.,micro,0.);vec3 n=normalize(cross(dFdx(microSurface),dFdy(microSurface)));if(n.y<0.)n=-n;
    float d=distance(p,uOrigin);float ripple=cos(d*1.65-uEvent*5.)*exp(-pow((d-uEvent*2.6)/3.4,2.))*.15*exp(-uEvent*.24)*step(.01,uEvent);n=normalize(n+vec3(normalize(p-uOrigin+vec2(.001))*ripple,0.).xzy);
    vec3 V=normalize(cameraPosition-vWorld);float ndv=abs(dot(n,V));float fres=.0204+.9796*pow(1.-ndv,5.);if(!gl_FrontFacing)fres=max(fres,1.-smoothstep(.59,.76,ndv));
    vec2 distort=n.xz*.012*min(1.,25./max(vViewDepth,1.));vec2 uv=gl_FragCoord.xy/uResolution;vec2 refUv=clamp(vReflect.xy/vReflect.w+distort,vec2(.002),vec2(.998));
    vec3 reflected=texture2D(uReflection,refUv).rgb;vec3 refracted=texture2D(uRefraction,clamp(uv+distort*.65,vec2(.002),vec2(.998))).rgb;
    float floorDepth=-linearZ(texture2D(uDepth,clamp(uv+distort*.65,vec2(.002),vec2(.998))).r);float thickness=max(0.,floorDepth-vViewDepth);
    vec3 water=mix(vec3(.004,.014,.029),vec3(.006,.039,.070),uDay);vec3 absorption=exp(-vec3(.22,.064,.043)*min(thickness,100.));vec3 transmitted=refracted*absorption+water*(1.-exp(-thickness*.07));
    if(!gl_FrontFacing){transmitted=mix(refracted,vec3(.014,.115,.18)*(.2+.8*uDay),.54);reflected=vec3(.006,.035,.057)*(.25+.75*uDay)+vec3(.013,.037,.046)*pow(ndv,3.);}
    vec3 col=mix(transmitted,reflected,fres);
    vec3 H=normalize(V+normalize(uSun));float ndh=max(0.,dot(n,H));float rough=.055;float denominator=ndh*ndh*(rough*rough-1.)+1.;float ggx=rough*rough/(3.14159*denominator*denominator);float spec=min(1.8,ggx*.012)*max(0.,uSun.y)*uDay;
    col+=vec3(1.,.84,.61)*spec*(gl_FrontFacing?1.:.12);
    float foam=pow(max(0.,sin(d*2.-uEvent*5.3+fine(p*2.,uTime)*9.)),9.)*exp(-pow((d-uEvent*2.5)/2.,2.))*exp(-uEvent*.26)*step(.01,uEvent);col=mix(col,vec3(.50,.66,.66)*(.25+.75*uDay),foam*.60);
    col+=vec3(1.,.27,.045)*uFire*exp(-d*d/70.)*exp(-uTail*.07)*(.15+.3*pow(ndv,3.));
    float distanceFade=1.-exp(-distance(cameraPosition,vWorld)*.00029);vec3 horizon=mix(vec3(.005,.0085,.015),vec3(.126,.206,.26),uDay);if(gl_FrontFacing)col=mix(col,horizon,distanceFade);
    gl_FragColor=vec4(col,1.);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
    }`});
  // Nonuniform tessellation concentrates vertices around the launch without a visible patch edge.
  const geometry=new THREE.PlaneGeometry(2,2,256,256);geometry.rotateX(-Math.PI/2);const a=geometry.attributes.position;const warp=v=>Math.sign(v)*(Math.pow(Math.abs(v),2.1)*5000+Math.pow(Math.abs(v),8)*45000);for(let i=0;i<a.count;i++){a.setXYZ(i,warp(a.getX(i)),0,warp(a.getZ(i)));}a.needsUpdate=true;geometry.computeBoundingSphere();
  const water=new THREE.Mesh(geometry,material);water.frustumCulled=false;scene.add(water);
  const options={minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,format:THREE.RGBAFormat};
  const reflection=new THREE.WebGLRenderTarget(640,400,options),refraction=new THREE.WebGLRenderTarget(640,400,options);refraction.depthTexture=new THREE.DepthTexture(640,400,THREE.UnsignedIntType);
  uniforms.uReflection.value=reflection.texture;uniforms.uRefraction.value=refraction.texture;uniforms.uDepth.value=refraction.depthTexture;
  const mirrorCamera=new THREE.PerspectiveCamera(),mirrorTarget=new THREE.Vector3(),dir=new THREE.Vector3(),size=new THREE.Vector2(),clip=new THREE.Plane();
  let tw=0,th=0;
  function render(camera,focus){
    renderer.getDrawingBufferSize(size);uniforms.uResolution.value.copy(size);uniforms.uUnder.value=1-M.smooth(-.5,.5,camera.position.y);
    const w=Math.max(256,Math.min(1280,Math.round(size.x*.66))),h=Math.max(160,Math.min(900,Math.round(size.y*.66)));if(w!==tw||h!==th){reflection.setSize(w,h);refraction.setSize(w,h);tw=w;th=h;}
    water.visible=false;const saved=renderer.getRenderTarget();renderer.setRenderTarget(refraction);renderer.render(scene,camera);
    mirrorCamera.copy(camera);mirrorCamera.position.copy(camera.position);mirrorCamera.position.y*=-1;camera.getWorldDirection(dir);dir.y*=-1;mirrorTarget.copy(mirrorCamera.position).add(dir);mirrorCamera.up.set(0,-1,0);mirrorCamera.lookAt(mirrorTarget);mirrorCamera.updateMatrixWorld();
    uniforms.uTextureMatrix.value.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1).multiply(mirrorCamera.projectionMatrix).multiply(mirrorCamera.matrixWorldInverse);
    clip.normal.set(0,camera.position.y>=0?1:-1,0);clip.constant=.10;renderer.clippingPlanes=[clip];renderer.setRenderTarget(reflection);renderer.render(scene,mirrorCamera);renderer.clippingPlanes=[];
    renderer.setRenderTarget(saved);water.visible=true;renderer.render(scene,camera);
  }
  return{mesh:water,material,uniforms,render,targets:[reflection,refraction]};
};
