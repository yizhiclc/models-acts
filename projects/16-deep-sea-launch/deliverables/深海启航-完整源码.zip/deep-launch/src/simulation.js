(function (root) {
  'use strict';
  const clamp = (x, a=0, b=1) => Math.min(b, Math.max(a, x));
  const smooth = (a,b,x) => { const u=clamp((x-a)/(b-a)); return u*u*(3-2*u); };
  const hash = n => { const v=Math.sin(n*127.1+311.7)*43758.5453123; return v-Math.floor(v); };
  const DURATION=28, SUB_Y=-27, LENGTH=8, TURN_START=8.88, IGNITION=9.10;
  // Narrative units, not real missile performance: a short ejection impulse, then coasting.
  const keys = [[5.3,-30.35,0],[6.2,-21.3,10],[7.8,-7.5,8],[8.85,.6,7.3],[IGNITION,2.39,7],[11,23,16],[16,149,30],[28,620,45]];
  function height(t,derivative=false) {
    if(t<=keys[0][0]) return derivative?0:keys[0][1];
    for(let i=0;i<keys.length-1;i++) {
      const a=keys[i],b=keys[i+1]; if(t>b[0]) continue;
      const d=b[0]-a[0],u=clamp((t-a[0])/d),u2=u*u,u3=u2*u;
      if(derivative)return (6*u2-6*u)*a[1]/d+(3*u2-4*u+1)*a[2]+(-6*u2+6*u)*b[1]/d+(3*u2-2*u)*b[2];
      return (2*u3-3*u2+1)*a[1]+(u3-2*u2+u)*d*a[2]+(-2*u3+3*u2)*b[1]+(u3-u2)*d*b[2];
    }
    return keys[keys.length-1][derivative?2:1];
  }
  function sea(x,z,t) {
    return .42*Math.sin(x*.066+z*.038+t*.85)+.21*Math.sin(x*.115-z*.069-t*.62)+.11*Math.sin(x*.219+z*.18+t*1.12)+.045*Math.sin(x*.44-z*.28+t*1.7);
  }
  // Authored screen choreography only: pitch and the curved path share one tangent.
  const driftX=t=>7.5-.24*t+.003*Math.max(0,t-6.2)**2;
  function pitch(t){const initial=.013*smooth(6.3,7.8,t)+.005*Math.sin(t*.58)*smooth(6.3,9,t),align=smooth(8.2,TURN_START,t),wet=initial*(1-align)+Math.atan2(.24-.006*Math.max(0,t-6.2),height(t,true))*align,turn=smooth(TURN_START,10.35,t);return wet*(1-turn)-.62*turn-.19*smooth(10.35,16,t);}
  const lateralSpeed=t=>-Math.tan(pitch(t))*height(t,true);
  const pathStep=1/240,pathX=[driftX(TURN_START)];
  for(let i=1;i<=Math.ceil((DURATION-TURN_START)/pathStep);i++){const a=TURN_START+(i-1)*pathStep,b=a+pathStep;pathX.push(pathX[i-1]+pathStep*(lateralSpeed(a)+4*lateralSpeed((a+b)/2)+lateralSpeed(b))/6);}
  function horizontal(t){if(t<=TURN_START)return driftX(t);const p=(t-TURN_START)/pathStep,i=Math.floor(p),u=p-i,a=TURN_START+i*pathStep;return pathX[i]+pathStep*u*(lateralSpeed(a)+4*lateralSpeed(a+pathStep*u/2)+lateralSpeed(t))/6;}
  function impact(t){const a=t-IGNITION;return a<0?0:smooth(0,.035,a)*Math.exp(-Math.max(0,a-.035)*5.5)*(1-smooth(.55,.9,a));}
  function sample(t) {
    t=clamp(t,0,DURATION);
    const subX=-.24*t;
    const x=horizontal(t),z=1.85,y=height(t),tilt=pitch(t);
    const top=y+LENGTH*Math.cos(tilt),headX=x-LENGTH*Math.sin(tilt);
    let phase=t<2?0:t<5.3?1:t<6.25?2:top<sea(headX,z,t)?3:t<IGNITION?4:t<10.6?5:6;
    return {t,subX,x,z,y,top,headX,tilt,lid:1.97*smooth(2,5,t),engine:smooth(IGNITION,IGNITION+.18,t),impact:impact(t),phase,water:sea(x,z,t),subY:SUB_Y};
  }
  const phases=[
    {name:'深海待机',en:'STANDBY',desc:'深蓝之下，静待启航。艇体保持平稳航行。',time:0},
    {name:'舱盖开启',en:'HATCH OPENING',desc:'铰链带动舱盖外翻，露出筒口与内衬。',time:2.4},
    {name:'水下出筒',en:'COLD EJECTION',desc:'短促出筒，局部气泡团膨胀。推进器尚未点火。',time:5.85},
    {name:'向光上浮',en:'UNDERWATER ASCENT',desc:'弹体惯性上行并逐渐减速，气泡尾迹留在身后。',time:6.95},
    {name:'穿越海面',en:'SURFACE CROSSING',desc:'弹体冲破水面，带起水幕，飞溅随重力回落。',time:8.25},
    {name:'出水点火',en:'AIR IGNITION',desc:'尾部离水即开始转向，点火烟团膨胀，喷焰迅速建立。',time:9.65},
    {name:'转向爬升',en:'PITCH & CLIMB',desc:'弹体沿弧线加速爬升，弯曲烟迹留在身后。',time:12.6}
  ];
  const api={clamp,smooth,hash,sample,height,sea,impact,phases,DURATION,SUB_Y,LENGTH,TURN_START,IGNITION};
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  else root.DeepMath=api;
})(typeof window!=='undefined'?window:globalThis);
