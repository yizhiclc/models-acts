/* Opt-in browser acceptance harness. Open index.html#qa. */
(() => {
  if(location.hash!=='#qa'||!window.DeepOcean)return;
  const api=window.DeepOcean,M=window.DeepMath,$=id=>document.getElementById(id);
  const panel=document.createElement('section');panel.id='qa-panel';panel.style.cssText='position:fixed;z-index:40;top:76px;left:22px;width:370px;max-height:calc(100vh - 160px);overflow:auto;padding:15px;background:#071c2ef5;border:1px solid #75bfbf;color:#cceee5;font:11px monospace;border-radius:8px';
  panel.innerHTML='<strong>浏览器验收 · 开发工具</strong><div style="display:flex;gap:10px;margin:12px 0"><button id="qa-run">运行一致性验收</button><button id="qa-hide">收起验收面板</button></div><pre id="qa-live" style="white-space:pre-wrap"></pre><pre id="qa-report" style="white-space:pre-wrap">尚未运行</pre>';
  document.body.appendChild(panel);$('qa-hide').onclick=()=>panel.hidden=true;
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));const frames=()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))); let running=false;
  setInterval(()=>{if(!running)$('qa-live').textContent=JSON.stringify(api.inspect(),null,1);},800);
  $('qa-run').onclick=async()=>{if(running)return;running=true;$('qa-run').disabled=true;const results=[];
    const check=(name,ok,detail)=>{results.push({name,pass:!!ok,detail});$('qa-report').textContent=JSON.stringify(results,null,1);};
    try {
      api.reset();api.seek(8.25);const hash=api.fingerprint();await wait(240);check('Pause freezes all task particles and transforms',api.fingerprint()===hash);
      api.seek(23);api.seek(5.8);api.seek(8.25);check('Backward seek restores identical particle state',hash===api.fingerprint());
      const crossing=api.inspect().crossings;check('Head exits, then tail exits, immediate turn, then ignition',crossing.head<crossing.tail&&crossing.tail<crossing.turn&&crossing.turn<crossing.ignition,crossing);
      api.seek(5.31);check('Hatch fully clear before ejection',api.inspect().geometry.hatchAngle===1.97);
      api.seek(M.IGNITION+.02);check('Ignition and rendered flame remain above the interface',api.inspect().mission.y>.785&&api.inspect().flameBottom>api.inspect().mission.water,api.inspect().flameBottom);
      api.seek(8.5);const wet=api.inspect();check('No ignition smoke, flash or engine light while submerged',wet.smokeParticles===0&&wet.ignitionParticles===0&&!wet.effects.flare&&wet.effects.light===0);
      api.seek(M.IGNITION+.08);const flash=api.inspect(),flashHash=api.fingerprint(),flashCamera=JSON.stringify(flash.camera);check('Ignition immediately emits a lit expanding smoke burst',flash.ignitionParticles>50&&flash.smokeParticles>0&&flash.effects.light>400&&flash.mission.impact>.7,{burst:flash.ignitionParticles,trail:flash.smokeParticles,light:flash.effects.light});
      await wait(240);check('Pause freezes ignition smoke, flash and camera impulse',flashHash===api.fingerprint()&&flashCamera===JSON.stringify(api.inspect().camera));
      api.seek(14);api.seek(M.IGNITION+.08);check('Rewind exactly restores the ignition burst and impulse',flashHash===api.fingerprint()&&flashCamera===JSON.stringify(api.inspect().camera));
      let aligned=true,minClearance=Infinity;for(const t of[9.2,9.65,10.1,12.6,20]){api.seek(t);const info=api.inspect(),tip=info.effects.flameTip,root=info.effects.flameRoot,angle=Math.atan2(tip[0]-root[0],root[1]-tip[1]);aligned&&=Math.abs(angle-info.mission.tilt)<.00001;minClearance=Math.min(minClearance,tip[1]-M.sea(tip[0],tip[2],t));}check('Tilted jet follows the nozzle and stays above the waves',aligned&&minClearance>0&&M.sample(9.65).tilt<-.25,{aligned,minClearance});
      api.seek(9.65);const time=api.inspect().state.time;$('daySlider').value=1.75;$('daySlider').dispatchEvent(new Event('input'));await wait(50);check('Day change does not reset mission',api.inspect().state.time===time&&api.inspect().state.day===1.75);
      $('clockRate').value='1800';$('clockRate').dispatchEvent(new Event('change'));$('clockAuto').checked=true;$('clockAuto').dispatchEvent(new Event('change'));const day=api.inspect().state.day;await wait(220);await frames();check('Independent day clock advances during mission pause',api.inspect().state.day>day&&api.inspect().state.time===time);$('clockAuto').checked=false;$('clockAuto').dispatchEvent(new Event('change'));$('daySlider').value=14.5;$('daySlider').dispatchEvent(new Event('input'));
      api.reset();$('speedButton').click();$('speedButton').click();$('playButton').click();const at=performance.now();await wait(450);await frames();$('playButton').click();const delta=api.inspect().state.time,wall=(performance.now()-at)/1000;check('0.25× slows the entire mission clock',delta>wall*.18&&delta<wall*.32,{delta,wall,speed:api.inspect().state.speed});$('speedButton').click();
      api.reset();api.seek(28);api.seek(0);const memory0=api.inspect().resources;let maxParticles=0;for(let replay=0;replay<20;replay++){for(const t of[0,5.8,6.5,8.25,9.18,9.65,10.1,12,20,28,0]){api.seek(t);maxParticles=Math.max(maxParticles,api.inspect().particles);}if(replay%4===0)await wait(0);}
      const last=api.inspect();check('Twenty complete scrub/replay cycles do not add GPU resources',JSON.stringify(last.resources)===JSON.stringify(memory0),{before:memory0,after:last.resources,maxParticles,capacity:last.particleCapacity});
      check('Reset removes every task particle and keeps one missile',last.particles===0&&last.geometry.missileCount===1&&last.geometry.hatchAngle===0);
      let views=true;for(let i=0;i<5;i++){api.chooseView(i);api.seek(i===0?0:i===1?5.8:i===2?6.95:i===3?8.25:12.6);const c=api.inspect().camera;views&&=Number.isFinite(c.x+c.y+c.z);}check('All five recommended cameras remain finite',views);
      const external=performance.getEntriesByType('resource').map(e=>e.name).filter(u=>/^https?:/.test(u)&&!u.startsWith(location.origin+'/'));check('No external runtime resources requested',external.length===0,external);
      api.reset();const audioBefore=api.inspect().audio;if(!audioBefore)$('muteButton').click();for(let i=0;i<6;i++){api.seek(9.65);$('playButton').click();await wait(20);$('playButton').click();api.reset();}await wait(300);const audio=api.inspect().audio;check('Audio graph is reused and pause ramps gain to zero',audio&&audio.nodeCount===10&&audio.masterTarget<.001,audio);if(!api.inspect().state.muted)$('muteButton').click();
      api.reset();check('Final scene restored to initial recommendation',api.inspect().state.time===0&&api.inspect().state.auto&&api.inspect().state.view===0);
    }catch(e){check('Harness execution',false,String(e.stack||e));}
    const report={version:api.version,environment:navigator.userAgent,protocol:location.protocol,passed:results.filter(r=>r.pass).length,total:results.length,results};$('qa-report').textContent=JSON.stringify(report,null,2);$('qa-live').textContent='验收完成';running=false;$('qa-run').disabled=false;
  };
})();
